<?php


require __DIR__ . '/vendor/autoload.php';

use App\Application;

Application::run();

